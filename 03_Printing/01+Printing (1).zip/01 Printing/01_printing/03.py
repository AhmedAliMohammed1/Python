
print('Hello \nWorld\nI am Mostafa')

"""
Hello 
World
I am Mostafa

\n Things starting with \ are called escape characters
\n means add a NEW line now
"""

print(' Hello \n  World\n   I am Mostafa')
"""
 Hello 
  World
   I am Mostafa
"""