

# This is comment. Interpreter IGNORE
print('Hello World')            # Hello World
print("Hello World")            # Hello World

# notes
# print is called a function (later)
# ( )       are called parentheses
# '   '     are called single quotes
# "  "      are called double quotes
# H e l W   are called letters :)
# 'Hello World' we call it a string (sequence of letters)
# Hello World   The letter between Hello and World is SPACE
# Above program outputs 2 LINES
