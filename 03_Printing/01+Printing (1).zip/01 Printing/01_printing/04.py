

print('Hello '
      'World '
      'I am Mostafa')

"""
Hello World I am Mostafa

Line 3-5 are a SINGLE command for print
    We can split on several lines
"""
