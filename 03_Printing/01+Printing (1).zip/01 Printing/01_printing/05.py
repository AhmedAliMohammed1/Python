
# we can do simple arithmatic!
print(1+2+3)
print(3 * 4)
print      (6 / 2)
print(7 / 2)
print('7 / 2')      # this is a normal print msg

"""
6
12
3.0
3.5
7 / 2
"""