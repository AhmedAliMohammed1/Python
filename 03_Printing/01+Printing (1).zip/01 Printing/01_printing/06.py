


print("There is", 1, "instructor not", 2 * 3)

# There is 1 instructor not 6