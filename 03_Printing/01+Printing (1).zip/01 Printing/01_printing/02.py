

print('Hello')
print('World')
print('I am Mostafa')

"""
triple quotes Allows multiline comments
Nothing here is processed by Interpreter

Output from lines 3-5

Hello
World
I am Mostafa
"""
