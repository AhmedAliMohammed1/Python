

print ('Let\'s learn')  # use escape char \'  ..hmm
print ("let's learn")   # make use of ""

print ("Same for using \" in between")
print ('Same for using " in between')
